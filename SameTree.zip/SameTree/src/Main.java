//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {
    public static void main(String[] args) {


        Program program = new Program();

        // Example 1: p = [1,2,3], q = [1,2,3]
        Tree pTree = new Tree(1);
        pTree.left = new Tree(2);
        pTree.right = new Tree(3);

        Tree qTree = new Tree(1);
        qTree.left = new Tree(2);
        qTree.right = new Tree(3);

        System.out.println("Example 1: " + program.isSameTree(pTree, qTree));


        // Example 2: p = [1,2], q = [1,null,2]
        Tree pTree1 = new Tree(1);
        pTree1.left = new Tree(2);

        Tree qTree1 = new Tree(1);
        qTree1.right = new Tree(2);

        System.out.println("Example 2: " + program.isSameTree(pTree1, qTree1));

        // Example 3: p = [1,2,1], q = [1,1,2]
        Tree pTree2 = new Tree(1);
        pTree2.left = new Tree(2);
        pTree2.left = new Tree(1);

        Tree qTree2 = new Tree(1);
        qTree2.left = new Tree(1);
        qTree2.left = new Tree(2);

        System.out.println("Example 3: " + program.isSameTree(pTree2, qTree2));




    }
}