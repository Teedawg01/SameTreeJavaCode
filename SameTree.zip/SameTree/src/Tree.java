public class Tree
{
    int value;
    Tree left;
    Tree right;
    Tree() {}
    Tree(int value) {this.value = value;}
    Tree(int value, Tree left, Tree right)
    {
        this.value = value;
        this.left = left;
        this.right = right;
    }

}
class Program
{
    public boolean isSameTree(Tree p, Tree q)
    {
        if (p == null && q == null)
        {
         return true;
        }
        if (p == null || q == null)
        {
            return false;
        }

        return p.value == q.value &&
                isSameTree(p.left, q.left) && isSameTree(p.right, q.right);
    }
}